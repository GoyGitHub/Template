<?php include('dbconnection.php'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.css">
   <link rel="stylesheet" href="assets/css/styles.css">

   <style>
      .low-rating td {
         color: red !important;
      }
      table {
         font-family: 'Nunito Sans', sans-serif;
         width: 100%;
         border-collapse: collapse;
      }
      th, td {
         padding: 10px;
         border: 1px solid #ddd;
         text-align: left;
      }
      th {
         background-color: #f4f4f4;
      }
   </style>

   <title>UCX Data Bank - Audit Report</title>
</head>
<body>

   <!--=============== HEADER ===============-->
<header class="header" id="header">
   <div class="header__container" style="display: flex; justify-content: space-between; align-items: center;">
      <button class="header__toggle" id="header-toggle">
         <i class="ri-menu-line"></i>
      </button>

      <!-- Logo on the right -->
      <img src="assets/img/logo.png" alt="Logo" style="height: 40px; margin-right: 20px;">
   </div>
</header>

<nav class="sidebar" id="sidebar">
   <div class="sidebar__container">
      <div class="sidebar__user">
         <div class="sidebar__img">
            <img src="assets/img/perfil.png" alt="image">
         </div>
         <div class="sidebar__info">
            <h3>Juan Dela Cruz</h3>
            <span>Administrator</span>
         </div>
      </div>

      <div class="sidebar__content">
         <div>
            <h3 class="sidebar__title">MANAGE</h3>
            <div class="sidebar__list">
               <a href="dashboard.php" class="sidebar__link">
                  <i class="ri-pie-chart-2-fill"></i>
                  <span>Dashboard</span>
               </a>
               <a href="list.php" class="sidebar__link active-link">
                  <i class="ri-wallet-3-fill"></i>
                  <span>UCX Data Bank</span>
               </a>
               <a href="#" class="sidebar__link">
                  <i class="ri-calendar-fill"></i>
                  <span>UCX Connect</span>
               </a>
               <a href="audit_form.php" class="sidebar__link">
                  <i class="ri-arrow-up-down-line"></i>
                  <span>Unify Audit System (UAS)</span>
               </a>
               <a href="#" class="sidebar__link">
                  <i class="ri-bar-chart-box-fill"></i>
                  <span>HR Records</span>
               </a>
            </div>
         </div>

         <div>
            <h3 class="sidebar__title">SETTINGS</h3>
            <div class="sidebar__list">
               <a href="#" class="sidebar__link">
                  <i class="ri-settings-3-fill"></i>
                  <span>Settings</span>
               </a>
               <a href="#" class="sidebar__link">
                  <i class="ri-mail-unread-fill"></i>
                  <span>My Messages</span>
               </a>
               <a href="#" class="sidebar__link">
                  <i class="ri-notification-2-fill"></i>
                  <span>Notifications</span>
               </a>
            </div>
         </div>
      </div>

      <div class="sidebar__actions">
         <button>
            <i class="ri-moon-clear-fill sidebar__link sidebar__theme" id="theme-button">
               <span>Theme</span>
            </i>
         </button>
         <a href="login.php" class="sidebar__link">
            <i class="ri-logout-box-r-fill"></i>
            <span>Log Out</span>
         </a>
      </div>
   </div>
</nav>

<main class="main container" id="main">
   <h1 style="margin-bottom: 20px; font-family:'Nunito Sans', sans-serif; color:#0d1b3d;">Audit Report</h1>

   <div class="table-container" style="overflow-x:auto; background:#fff; border-radius:12px; box-shadow: 0 4px 20px rgba(0,0,0,0.05); padding: 24px;">
      <table>
         <thead>
            <tr>
               <th>Reviewer</th>
               <th>Agent Name</th>
               <th>Status</th>
               <th>Date</th>
               <th>Week</th>
               <th>Time</th>
               <th>Caller 1</th>
               <th>Duration</th>
               <th>Queue</th>
               <th>MDN</th>
               <th>Account No</th>
               <th>Rating</th>
               <th>Comments</th>
            </tr>
         </thead>
         <tbody>
            <?php
            $query = "SELECT * FROM agent_audit_sheet ORDER BY date DESC";
            $result = mysqli_query($conn, $query);

            if (mysqli_num_rows($result) > 0) {
               while ($row = mysqli_fetch_assoc($result)) {
                  $criteria = [
                     'adheres_schedule_login',
                     'proper_call_handling',
                     'product_knowledge',
                     'professional_tone',
                     'appropriate_language',
                     'accurate_documentation',
                     'empathy_support',
                     'resolution_effectiveness',
                     'policy_compliance',
                     'qa_guidelines'
                  ];

                  $score = 0;
                  foreach ($criteria as $item) {
                     if (isset($row[$item]) && strtolower($row[$item]) == 'yes') {
                        $score++;
                     }
                  }

                  $finalRating = round(($score / count($criteria)) * 10, 1);
                  $rowClass = $finalRating < 5 ? "low-rating" : "";

                  echo "<tr class='$rowClass'>";
                  echo "<td>" . htmlspecialchars($row['reviewer']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['agent_name']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['status']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['date']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['week']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['time']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['caller_name_1']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['duration']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['queue']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['mdn']) . "</td>";
                  echo "<td>" . htmlspecialchars($row['account_number']) . "</td>";
                  echo "<td>" . $finalRating . "</td>";
                  echo "<td>" . htmlspecialchars($row['comments']) . "</td>";
                  echo "</tr>";
               }
            } else {
               echo "<tr><td colspan='14'>No records found.</td></tr>";
            }
            ?>
         </tbody>
      </table>
   </div>
</main>

<script src="assets/js/main.js"></script>
</body>
</html>
