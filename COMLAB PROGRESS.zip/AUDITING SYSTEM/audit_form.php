<?php
include('dbconnection.php');

if (isset($_POST['submit'])) {
    $reviewer         = $_POST['reviewer'];
    $agent_name       = $_POST['agent_name'];
    $status           = $_POST['status'];
    $date             = $_POST['date'];
    $week             = $_POST['week'];
    $time             = $_POST['time'];
    $caller_name1     = $_POST['caller_name1'];
    $duration         = $_POST['duration'];
    $queue            = $_POST['queue'];
    $mdn              = $_POST['mdn'];
    $account_number   = $_POST['account_number'];

    $adheres_schedule_login    = $_POST['adheres_schedule_login'];
    $follows_call_procedure    = $_POST['follows_call_procedure'];
    $product_knowledge         = $_POST['product_knowledge'];
    $professional_tone         = $_POST['professional_tone'];
    $appropriate_language      = $_POST['appropriate_language'];
    $accurate_documentation    = $_POST['accurate_documentation'];
    $empathy_support           = $_POST['empathy_support'];
    $resolution_effectiveness  = $_POST['resolution_effectiveness'];
    $compliance_policy         = $_POST['compliance_policy'];
    $follows_qa_guidelines     = $_POST['follows_qa_guidelines'];

    $comments = $_POST['comment'];

    $query = "INSERT INTO agent_audit_sheet (
        reviewer, agent_name, status, date, week, time, 
        caller_name_1, duration, queue, caller_name_2, 
        mdn, account_number,
        adheres_schedule_login, follows_call_procedure, product_knowledge, 
        professional_tone, appropriate_language, accurate_documentation, 
        empathy_support, resolution_effectiveness, compliance_policy, 
        follows_qa_guidelines, comments
    ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )";

    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssssssssssssssssssssss",
        $reviewer, $agent_name, $status, $date, $week, $time,
        $caller_name1, $duration, $queue, $caller_name2,
        $mdn, $account_number,
        $adheres_schedule_login, $follows_call_procedure, $product_knowledge,
        $professional_tone, $appropriate_language, $accurate_documentation,
        $empathy_support, $resolution_effectiveness, $compliance_policy,
        $follows_qa_guidelines, $comments
    );

    if ($stmt->execute()) {
        echo "<p class='success'>Audit submitted successfully!</p>";
    } else {
        echo "<p class='error'>Error submitting audit: " . $stmt->error . "</p>";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Agent Audit Sheet</title>
   <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@400;600;700&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/remixicon/4.2.0/remixicon.css">
   <link rel="stylesheet" href="assets/css/styles.css">

   <style>
      body {
         font-family: 'Nunito Sans', sans-serif;
         background-color: #f4f6fa;
         color: #1a237e;
         margin: 0;
         padding: 0;
      }

      .main.container {
         padding: 2rem;
         max-width: 1300px;
         margin: 80px auto;
      }

      h1 {
         text-align: left;
         font-size: 2rem;
         margin-bottom: 2rem;
         font-weight: 700;
      }

      .info-bar {
         display: flex;
         flex-wrap: wrap;
         gap: 2rem;
         margin-bottom: 1.5rem;
         background: #fff;
         padding: 1rem;
         border-radius: 0.8rem;
         box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
         width: 120%;
      }

      .info-field {
         flex: 1;
         min-width: 250px;
      }

      .info-field label {
         font-weight: 600;
         margin-bottom: 0.5rem;
         display: block;
         color: #333;
      }

      .info-field input, .info-field textarea {
         width: 100%;
         padding: 0.6rem;
         border: 1px solid #ccc;
         border-radius: 0.8rem;
         font-size: 1rem;
      }

      table {
         width: 100%;
         border-collapse: collapse;
         background: #fff;
         box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
         border-radius: 0.8rem;
         overflow: hidden;
      }

      th, td {
         padding: 1rem;
         text-align: center;
         border-bottom: 1px solid #e0e0e0;
      }

      th {
         background-color: #1a237e;
         color: #fff;
         font-weight: 600;
      }

      td:first-child {
         text-align: left;
         font-weight: 600;
         color: #1a237e;
      }

      input[type="radio"] {
         transform: scale(1.2);
         cursor: pointer;
      }

      .submit-btn {
         margin-top: 1.5rem;
         background-color: #1a237e;
         color: white;
         padding: 0.75rem 2rem;
         border: none;
         border-radius: 0.5rem;
         font-size: 1rem;
         cursor: pointer;
         transition: background 0.3s ease;
      }

      .submit-btn:hover {
         background-color: #0d1b5e;
      }

      .success, .error {
         margin-top: 1rem;
         font-weight: 600;
         padding-left: 1rem;
      }

      .success {
         color: green;
      }

      .error {
         color: red;
      }
   </style>
</head>

<body>

   <!--=============== HEADER ===============-->
<header class="header" id="header">
   <div class="header__container" style="display: flex; justify-content: space-between; align-items: center;">
      <button class="header__toggle" id="header-toggle">
         <i class="ri-menu-line"></i>
      </button>

      <!-- Logo on the right -->
      <img src="assets/img/logo.png" alt="Logo" style="height: 40px; margin-right: 20px;">
   </div>
</header>

   <!--=============== SIDEBAR ===============-->
   <nav class="sidebar" id="sidebar">
      <div class="sidebar__container">
         <div class="sidebar__user">
            <div class="sidebar__img">
               <img src="assets/img/perfil.png" alt="image">
            </div>

            <div class="sidebar__info">
               <h3>Juan Dela Cruz</h3>
               <span>Administrator</span>
            </div>
         </div>

         <div class="sidebar__content">
            <div>
               <h3 class="sidebar__title">MANAGE</h3>

               <div class="sidebar__list">
                  <a href="dashboard.php" class="sidebar__link">
                     <i class="ri-pie-chart-2-fill"></i>
                     <span>Dashboard</span>
                  </a>
                  
                  <a href="list.php" class="sidebar__link">
                     <i class="ri-wallet-3-fill"></i>
                     <span>UCX Data Bank</span>
                  </a>

                  <a href="#" class="sidebar__link">
                     <i class="ri-calendar-fill"></i>
                     <span>UCX Connect</span>
                  </a>

                  <a href="audit_form.php" class="sidebar__link active-link">
                     <i class="ri-arrow-up-down-line"></i>
                     <span>Unify Audit System (UAS)</span>
                  </a>

                  <a href="#" class="sidebar__link">
                     <i class="ri-bar-chart-box-fill"></i>
                     <span>HR Records</span>
                  </a>
               </div>
            </div>

            <div>
               <h3 class="sidebar__title">SETTINGS</h3>

               <div class="sidebar__list">
                  <a href="#" class="sidebar__link">
                     <i class="ri-settings-3-fill"></i>
                     <span>Settings</span>
                  </a>

                  <a href="#" class="sidebar__link">
                     <i class="ri-mail-unread-fill"></i>
                     <span>My Messages</span>
                  </a>

                  <a href="#" class="sidebar__link">
                     <i class="ri-notification-2-fill"></i>
                     <span>Notifications</span>
                  </a>
               </div>
            </div>
         </div>

         <div class="sidebar__actions">
            <button>
               <i class="ri-moon-clear-fill sidebar__link sidebar__theme" id="theme-button">
                  <span>Theme</span>
               </i>
            </button>

         <a href="login.php" class="sidebar__link">
            <i class="ri-logout-box-r-fill"></i>
            <span>Log Out</span>
         </a>

         </div>
      </div>
   </nav>

   <!-- MAIN -->
   <main class="main container" style="margin-left: 350px;">
      <h1>Agent Audit Sheet</h1>

      <form method="POST">
         <div class="info-bar">
            <div class="info-field"><label>Reviewer:</label><input type="text" name="reviewer" required></div>
            <div class="info-field"><label>Agent's Name:</label><input type="text" name="agent_name" required></div>
            <div class="info-field"><label>Status:</label>
               <input type="text" name="status" list="status-options" required>
               <datalist id="status-options">
                  <option value="Regular"><option value="Probationary"><option value="Trainee"><option value="Others">
               </datalist>
            </div>
            <div class="info-field"><label>Date:</label><input type="date" name="date" required></div>
            <div class="info-field"><label>Week:</label><input type="text" name="week" required></div>
            <div class="info-field"><label>Time:</label><input type="time" name="time" required></div>
            <div class="info-field"><label>Caller's Name 1:</label><input type="text" name="caller_name1" required></div>
            <div class="info-field"><label>Duration:</label><input type="text" name="duration" required></div>
            <div class="info-field"><label>Queue:</label><input type="text" name="queue" required></div>
            <div class="info-field"><label>MDN:</label><input type="text" name="mdn" required></div>
            <div class="info-field"><label>Account Number:</label><input type="text" name="account_number" required></div>
         </div>

         <div style="overflow-x: auto; margin-left: 1px; width: 120%;">
            <table>
               <thead>
                  <tr><th>Audit Criteria</th><th>Yes</th><th>No</th><th>N/A</th></tr>
               </thead>
               <tbody>
                  <?php
                  $questions = [
                     "Adheres to schedule and login time" => "adheres_schedule_login",
                     "Follows proper call handling procedures" => "follows_call_procedure",
                     "Demonstrates product knowledge" => "product_knowledge",
                     "Maintains professional tone" => "professional_tone",
                     "Uses appropriate language" => "appropriate_language",
                     "Accurate documentation" => "accurate_documentation",
                     "Customer empathy and support" => "empathy_support",
                     "Problem resolution effectiveness" => "resolution_effectiveness",
                     "Compliance with company policy" => "compliance_policy",
                     "Follows QA guidelines" => "follows_qa_guidelines"
                  ];

                  foreach ($questions as $label => $name) {
                     echo "<tr>";
                     echo "<td>$label</td>";
                     echo "<td><input type='radio' name='$name' value='Yes' required></td>";
                     echo "<td><input type='radio' name='$name' value='No'></td>";
                     echo "<td><input type='radio' name='$name' value='N/A'></td>";
                     echo "</tr>";
                  }
                  ?>
               </tbody>
            </table>
         </div>

         <div class="info-bar" style="margin-top: 2rem;">
            <div class="info-field" style="flex: 1 1 100%;">
               <label>Comments:</label>
               <textarea name="comment" rows="3"></textarea>
            </div>
         </div>

         <button type="submit" name="submit" class="submit-btn">Submit Audit</button>
      </form>
   </main>

   <script src="assets/js/main.js"></script>
</body>
</html>
